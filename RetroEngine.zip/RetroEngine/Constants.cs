﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RetroEngine
{
    public static class Constants
    {
        public static float ResolutionY = 720;
    }
}
