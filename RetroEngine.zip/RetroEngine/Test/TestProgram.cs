﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetroEngine.Test
{
    internal class TestProgram
    {
        public static void Main()
        {
            TestGame game = new TestGame();
            game.devMenu = new DevMenu();
            game.Run();
        }
    }
}
